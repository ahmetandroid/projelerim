from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.


def home(request):
    context={'title':"Anasayfa",'baslik':'Projeler Listesi','icerik':'Burada yapılan projelerin açıklaması olacak....'}
    return render(request,'home.html',context=context)

def listele(request):
    context={'title':"Listele",'baslik':'Okul Projeler Listesi','icerik':'Burada yapılan projelerin tümü listelenecek....'}
    return render(request,'about.html',context=context)



